<nav class="navbar navbar-light bg-light justify-content-between">
  <a class="navbar-brand">Task Organiser</a>
   <a href="index.php" class="btn btn-outline-success my-2 my-sm-0" type="submit">View all Task</a>
</nav>